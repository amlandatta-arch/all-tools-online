#!/usr/bin/env python3
"""
Generate all tool pages for AllToolsOnline
This script creates individual HTML pages for each tool with working functionality
"""

import os
import json
import re

def generate_slug(name):
    """Convert tool name to URL-friendly slug"""
    slug = name.lower()
    slug = re.sub(r'[^a-z0-9]+', '-', slug)
    slug = slug.strip('-')
    return slug

# Tool categories and data
categories = [
    {
        'id': 'calculators',
        'title': 'Calculators',
        'tools': [
            ['Percentage Calculator','Quick percent calculations','%'],
            ['Age Calculator','Calculate exact age from DOB','🎂'],
            ['BMI Calculator','Body Mass Index calculator','⚖️'],
            ['Loan EMI Calculator','Monthly EMI estimates','🏦'],
            ['Simple Interest Calculator','Simple interest on principal','📈'],
            ['Compound Interest Calculator','Compound interest estimates','🔁'],
            ['Discount Calculator','Calculate discounts easily','💸'],
            ['Tip Calculator','Split tips and bills','🍽️'],
            ['GST Calculator','GST tax calculations','🧾'],
            ['Unit Converter','Length/weight/volume units','🔧'],
            ['Fraction to Decimal Converter','Convert fractions to decimals','➗'],
            ['Square Root Calculator','Compute square roots','√'],
            ['Ratio Calculator','Simplify and compare ratios','🔢'],
            ['Average Calculator','Mean / average values','∑'],
            ['Currency Converter','Static-rate currency convert','💱'],
            ['Roman Numeral Converter','Roman ↔ Arabic numbers','🪙'],
            ['Power Calculator','Exponents and powers','⚡'],
            ['LCM GCD Calculator','Lowest common multiple & GCD','📐'],
            ['Base Converter','Binary/hex/oct/dec convert','🔢'],
            ['Percentage Increase/Decrease Calculator','Change % calculations','⬆️⬇️'],
            ['Time Difference Calculator','Difference between two times','⏱️'],
            ['Date to Day Calculator','Find weekday from a date','📅'],
            ['Countdown Calculator','Countdown to a date/time','⏳'],
            ['Salary Calculator','Monthly/yearly salary math','💼'],
            ['Calorie Calculator','Estimate daily calories','🍎'],
            ['Pregnancy Due Date Calculator','Estimate due dates','🤰'],
            ['Fuel Cost Calculator','Estimate fuel expenses','⛽'],
            ['Electricity Bill Estimator','Estimate monthly bill','💡'],
            ['Age Difference Calculator','Compare ages between people','👥'],
            ['Discount vs Markup Calculator','Compare discount & markup','🔍']
        ]
    },
    {
        'id': 'text-tools',
        'title': 'Text & Writing Tools',
        'tools': [
            ['Uppercase Converter','Convert text to UPPERCASE','🔠'],
            ['Lowercase Converter','Convert text to lowercase','🔡'],
            ['Sentence Case Converter','Sentence case formatting','✍️'],
            ['Title Case Converter','Title Case formatting','📚'],
            ['Remove Extra Spaces','Trim and normalize spaces','🧽'],
            ['Word Counter','Count words in text','🔢'],
            ['Character Counter','Count characters','🔣'],
            ['Line Counter','Count lines','📏'],
            ['Remove Duplicate Lines','Remove repeated lines','♻️'],
            ['Sort Lines Alphabetically','Sort lines A→Z','🔤'],
            ['Reverse Text','Reverse the characters','↩️'],
            ['Base64 Encoder/Decoder','Base64 encode/decode','🧩'],
            ['URL Encoder/Decoder','Percent-encode/decode URLs','🔗'],
            ['JSON Formatter','Pretty-print JSON','{}'],
            ['XML to JSON Converter','Convert XML to JSON','🗂️'],
            ['CSV to JSON Converter','CSV → JSON conversion','📄'],
            ['JSON to CSV Converter','JSON → CSV conversion','📑'],
            ['Text to Binary Converter','Text ↔ Binary','💻'],
            ['Binary to Text Converter','Binary ↔ Text','🔁'],
            ['Text to Morse Code Converter','Text ↔ Morse','•−•−'],
            ['Morse to Text Converter','Morse ↔ Text','•−•−'],
            ['Text Difference Checker','Compare two text versions','⚖️'],
            ['Palindrome Checker','Check palindromes','🔁'],
            ['Word Frequency Analyzer','Count word frequency','📊'],
            ['Random Word Generator','Generate random words','🎲'],
            ['Lorem Ipsum Generator','Placeholder text generator','📜'],
            ['Paragraph Reformatter','Reflow paragraphs','🔧'],
            ['Find & Replace Tool','Find and replace text','🔎'],
            ['Typing Speed Tester','Check typing speed (WPM)','⌨️'],
            ['Read Time Estimator','Estimate reading time','⏲️']
        ]
    },
    {
        'id': 'developer-tools',
        'title': 'Developer Tools',
        'tools': [
            ['HTML Minifier','Minify HTML files','🧩'],
            ['CSS Minifier','Minify CSS files','🎨'],
            ['JS Minifier','Minify JavaScript','⚙️'],
            ['HTML Beautifier','Pretty-print HTML','✨'],
            ['CSS Beautifier','Pretty-print CSS','🖌️'],
            ['JS Beautifier','Pretty-print JavaScript','🛠️'],
            ['Regex Tester','Test regular expressions','🔍'],
            ['Markdown to HTML Converter','MD → HTML','📝'],
            ['Color Picker','Pick color values','🎨'],
            ['Gradient Generator','Create CSS gradients','🌈'],
            ['Box Shadow Generator','CSS box-shadow builder','🕶️'],
            ['Border Radius Generator','Generate border-radius','◻️'],
            ['CSS Text Shadow Generator','Text-shadow maker','🖋️'],
            ['Favicon Generator','Simple favicon creator','🔖'],
            ['Meta Tag Generator','Generate SEO meta tags','🏷️'],
            ['Robots.txt Generator','Create robots.txt','🤖'],
            ['Sitemap Generator','Static XML sitemap','🗺️'],
            ['Base64 Image Encoder','Image → Base64','🖼️'],
            ['JSON Parser','Parse and view JSON','🔧'],
            ['Password Generator','Generate secure passwords','🔐'],
            ['Password Strength Checker','Check password safety','🛡️'],
            ['QR Code Generator','Create QR codes (client-side)','📱'],
            ['Barcode Generator','Generate barcodes','📦'],
            ['IP Validator','Validate IP format','🌐'],
            ['Email Validator','Validate email format','✉️']
        ]
    },
    {
        'id': 'file-tools',
        'title': 'File & Conversion Tools',
        'tools': [
            ['Image to Base64 Converter','Image → Base64 string','🖼️'],
            ['Base64 to Image Converter','Base64 → Image','📥'],
            ['Image Compressor','Compress images client-side','🗜️'],
            ['Image Cropper','Crop images in-browser','✂️'],
            ['PDF to Text Extractor','Extract text from PDF','📄'],
            ['Text to PDF Converter','Text → PDF','🖨️'],
            ['Text to Image Converter','Text → Image','🖼️'],
            ['HTML to PDF Converter','HTML → PDF','📑'],
            ['CSV Viewer','View CSV in table form','📊'],
            ['CSV Merger','Merge multiple CSV files','🔗'],
            ['Excel to CSV Converter','XLSX → CSV','📥'],
            ['JSON File Viewer','View JSON files','📁'],
            ['Text Merge/Split Tool','Merge or split files','🔀'],
            ['File Renamer','Bulk rename simulator','✏️'],
            ['File Size Estimator','Estimate download sizes','⚖️']
        ]
    },
    {
        'id': 'design-tools',
        'title': 'Design & Visual Tools',
        'tools': [
            ['Color Palette Generator','Generate color palettes','🎨'],
            ['Color Contrast Checker','WCAG contrast checker','🔍'],
            ['HEX to RGB Converter','HEX → RGB','#️⃣'],
            ['RGB to HEX Converter','RGB → HEX','🎯'],
            ['Gradient Background Maker','Design gradients','🌈'],
            ['CSS Pattern Generator','Create CSS patterns','🔳'],
            ['Image Color Picker','Pick color from image','🖌️'],
            ['Font Pairing Generator','Suggest font pairs','🔠'],
            ['Font Preview Tool','Preview fonts','🔤'],
            ['ASCII Art Generator','Text → ASCII art','💻'],
            ['Meme Text Adder','Add captions to images','😂'],
            ['Image Flipper','Flip image horizontally/vertically','🔁'],
            ['Image Resizer','Resize images','📏'],
            ['Icon Size Generator','Generate app icon sizes','🗂️'],
            ['Image Blur/Sharpen','Blur and sharpen images','🌀'],
            ['Collage Maker','Create simple collages','🖼️'],
            ['Screenshot Mockup Frame','Frame screenshots','🖼️'],
            ['CSS Animation Previewer','Preview CSS animations','🎞️'],
            ['Favicon Background Changer','Edit favicon backgrounds','🔖'],
            ['Typography Scale Calculator','Typography scale helper','🔡']
        ]
    },
    {
        'id': 'utility-tools',
        'title': 'Everyday Utility Tools',
        'tools': [
            ['Stopwatch','Simple stopwatch','⏱️'],
            ['Timer','Countdown timer','⏲️'],
            ['Alarm Clock','Set alarms in browser','⏰'],
            ['Calendar','Mini calendar widget','📅'],
            ['To-Do List','Simple task list (local)','🗒️'],
            ['Pomodoro Timer','Focus timer','🍅'],
            ['Random Number Generator','Generate random numbers','🎲'],
            ['Random Name Picker','Pick a random name','🧾'],
            ['Coin Toss Simulator','Heads or tails','🪙'],
            ['Dice Roller','Roll virtual dice','🎲'],
            ['QR Code Scanner','Scan QR codes (camera)','📷'],
            ['Barcode Scanner','Scan barcodes (camera)','🔎'],
            ['Notepad','Simple in-browser note pad','📝'],
            ['Markdown Editor','Write markdown locally','📘'],
            ['Password Manager','Local password vault','🔐'],
            ['Expense Tracker','Track expenses (local)','💳'],
            ['Simple Journal','Daily journal (local)','📓'],
            ['URL Shortener','Client-side short link demo','🔗'],
            ['Random Quote Generator','Generate quotes','🗣️'],
            ['Birthday Reminder','Track upcoming birthdays','🎉'],
            ['Countdown Timer','Event countdown','⏳'],
            ['Clipboard Manager','Manage clipboard items','📋'],
            ['Screen Color Picker','Pick on-screen color','🎨'],
            ['Mouse Click Counter','Count clicks','🖱️'],
            ['File Drag & Drop Counter','Count uploaded files','📤']
        ]
    },
    {
        'id': 'seo-tools',
        'title': 'SEO & Content Tools',
        'tools': [
            ['Keyword Density Checker','Check keyword frequency','🔑'],
            ['Meta Description Counter','Meta length check','📝'],
            ['Title Length Checker','SEO title length checker','🏷️'],
            ['Slug Generator','Create URL slugs','🧭'],
            ['Readability Checker','Flesch readability score','📘'],
            ['URL Extractor','Extract URLs from text','🔗'],
            ['Link Counter','Count links in content','🔢'],
            ['Broken Link Checker','Find broken links (scan)','🔍'],
            ['Word-to-Title Generator','Create titles from text','📰'],
            ['Text-to-Meta Generator','Generate meta tags','🏷️'],
            ['Robots Meta Tag Tester','Test robots meta tags','🤖'],
            ['Sitemap Viewer','View sitemap XML','🗺️'],
            ['HTML Word Counter','Count words in HTML','📄'],
            ['Article Outline Generator','Generate article outlines','✍️'],
            ['Paragraph Simplifier','Simplify complex paragraphs','🪄']
        ]
    },
    {
        'id': 'education-tools',
        'title': 'Education & Learning Tools',
        'tools': [
            ['GPA Calculator','Calculate GPA','🎓'],
            ['Grade Percentage Calculator','Convert marks to %','📊'],
            ['Typing Test','Typing speed and accuracy','⌨️'],
            ['Flashcard Maker','Create flashcards','🃏'],
            ['Equation Solver','Solve math equations','➗'],
            ['Random Quiz Generator','Generate quick quizzes','❓'],
            ['Unit Conversion (Science)','Scientific unit convert','🔬'],
            ['Periodic Table','Periodic table reference','🧪'],
            ['Chemical Equation Balancer','Balance chemical equations','⚗️'],
            ['Distance-Speed-Time Calculator','DST calculations','🚗'],
            ['Average Marks Calculator','Compute averages','📈'],
            ['Word Unscrambler','Unscramble words','🔡'],
            ['Anagram Solver','Find anagrams','🔀'],
            ['Spelling Checker','Check spelling locally','📝'],
            ['Vocabulary Trainer','Improve vocabulary','📚'],
            ['Reading Speed Test','Reading speed measurement','📖'],
            ['Random Trivia Generator','Trivia questions','🎲'],
            ['Sentence Shuffler','Shuffle sentence words','🔁'],
            ['Worksheet Generator','Make printable worksheets','🖨️'],
            ['Study Schedule Maker','Plan study schedules','🗓️']
        ]
    },
    {
        'id': 'fun-tools',
        'title': 'Fun & Entertainment Tools',
        'tools': [
            ['Random Joke Generator','Get random jokes','😂'],
            ['Truth or Dare Generator','Play truth or dare','❗'],
            ['Would You Rather Generator','Would you rather prompts','🤔'],
            ['Love Percentage Calculator','Fun compatibility %','💘'],
            ['Compatibility Test','Match compatibility','❤️'],
            ['Horoscope Reader','Daily horoscope (static)','♓'],
            ['Fortune Cookie Generator','Random fortunes','🥠'],
            ['Lucky Number Picker','Pick a lucky number','🔢'],
            ['Birthday Personality Checker','Birthday-based fun read','🎂'],
            ['Meme Caption Maker','Add captions to images','📸'],
            ['Random Quote Wallpaper Maker','Create quote wallpapers','🖼️'],
            ['Mood Tracker','Track daily mood','🙂'],
            ['Daily Affirmation Generator','Positive affirmations','🌟'],
            ['Random Movie Picker','Pick a movie to watch','🎬'],
            ['Random Song Name Generator','Suggest songs','🎵']
        ]
    },
    {
        'id': 'misc-tools',
        'title': 'Misc / Advanced Tools',
        'tools': [
            ['UUID Generator','Generate RFC-compliant UUIDs','🔑'],
            ['Hash Generator (MD5/SHA256)','Create hashes','🔐'],
            ['Diff Checker','Compare text/file diffs','🔎'],
            ['LocalStorage Viewer','Inspect localStorage','📦'],
            ['Cookie Viewer','View and edit cookies','🍪'],
            ['JSON Compressor','Compress JSON payloads','📦'],
            ['HTML Entity Encoder/Decoder','Encode HTML entities','&amp;'],
            ['Text Encrypt/Decrypt Tool','Simple encryption demo','🔏'],
            ['Notes Sync (Local)','Sync notes locally','📝'],
            ['Random Data Generator','Generate names/emails','🎲'],
            ['Base Converter','Convert number bases','🔢'],
            ['Date Formatter','Format dates and times','📅'],
            ['Timestamp Converter','Unix timestamp converters','🕰️'],
            ['Epoch to Human Date Converter','Convert epoch to date','📆'],
            ['Random Password List Generator','Generate multiple passwords','🔑']
        ]
    }
]

# Create tools directory structure
base_dir = os.path.dirname(os.path.abspath(__file__))
tools_dir = os.path.join(base_dir, 'tools')

# Create directories
for category in categories:
    cat_dir = os.path.join(tools_dir, category['id'])
    os.makedirs(cat_dir, exist_ok=True)

print(f"Created directory structure in {tools_dir}")
print(f"Total categories: {len(categories)}")
total_tools = sum(len(cat['tools']) for cat in categories)
print(f"Total tools to generate: {total_tools}")
print("\nGenerating tool pages...")

# Import tool templates
from tool_templates import get_tool_template, get_tool_script

# Generate each tool page
count = 0
for category in categories:
    for tool in category['tools']:
        tool_name, tool_desc, tool_icon = tool
        slug = generate_slug(tool_name)
        
        # Get similar tools (same category, exclude current)
        similar_tools = [t for t in category['tools'] if t[0] != tool_name][:4]
        
        # Generate HTML content
        html_content = get_tool_template(
            tool_name=tool_name,
            tool_desc=tool_desc,
            tool_icon=tool_icon,
            category_id=category['id'],
            category_title=category['title'],
            similar_tools=similar_tools
        )
        
        # Write file
        file_path = os.path.join(tools_dir, category['id'], f'{slug}.html')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        count += 1
        if count % 20 == 0:
            print(f"Generated {count}/{total_tools} tools...")

print(f"\n✅ Successfully generated {count} tool pages!")
print(f"📁 Location: {tools_dir}")
